package com.kh.dic;

public class DictionaryException extends RuntimeException {
    public DictionaryException(String message){
        super(message);
    }

}
